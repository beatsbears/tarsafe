#!/bin/bash
echo "I am bad"